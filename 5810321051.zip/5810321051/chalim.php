<?php

$bot_token = "8493231027:AAGtiUqhPLYymjIYCf8DCrA2JMErRf45SKw";
$sudo_port = "5810321051";
$dev_id = "fyilk_team";
$dev_name = "fyilk_team";
$sudo_user = ["5810321051"];
$id_sender = "5810321051";
$dateBuy = "1404/01/01 | 13:23:43";
$expir = "1404/02/01 | 13:23:43";
// به اینا دس نزن رت بگا میره
$file = "fateh-fe213-firebase-adminsdk-fbsvc-a7e5359749.json";
$project_id = "fateh-fe213";

?>